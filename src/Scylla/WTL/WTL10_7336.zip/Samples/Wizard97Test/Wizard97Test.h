// Wizard97Test.h
